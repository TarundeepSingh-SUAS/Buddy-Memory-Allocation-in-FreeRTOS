extern "C" {
#include <FreeRTOS.h>
#include <task.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
}

#define BLOCK_COUNT 8
#define BLOCK_SIZE  1024  // 1 KB each

static void print_stat(const char *label, size_t value)
{
    printf("%-22s : %u bytes\r\n", label, (unsigned)value);
}

void merge_test_task(void * /*param*/)
{
    printf("\r\n=== FREE BLOCK MERGING TEST ===\r\n");

    void *ptr[BLOCK_COUNT] = {0};

    printf("\r\n--- STEP 1: Allocate 8 equal blocks ---\r\n");
    for (int i = 0; i < BLOCK_COUNT; i++)
    {
        ptr[i] = pvPortMalloc(BLOCK_SIZE);
        printf("alloc[%d] = %p\r\n", i, ptr[i]);
    }

    printf("\r\n--- STEP 2: Free every second block (create holes) ---\r\n");
    for (int i = 1; i < BLOCK_COUNT; i += 2)
    {
        printf("free[%d] = %p\r\n", i, ptr[i]);
        vPortFree(ptr[i]);
    }

    printf("\r\n--- HEAP STATUS (after partial free) ---\r\n");
    HeapStats_t stats1;
    memset(&stats1, 0, sizeof(stats1));
    vPortGetHeapStats(&stats1);

    print_stat("Largest free block",    stats1.xSizeOfLargestFreeBlockInBytes);
    print_stat("Smallest free block",   stats1.xSizeOfSmallestFreeBlockInBytes);
    print_stat("Number of free blocks", stats1.xNumberOfFreeBlocks);

    printf("\r\n--- STEP 3: Free remaining blocks (should merge fully) ---\r\n");
    for (int i = 0; i < BLOCK_COUNT; i += 2)
    {
        printf("free[%d] = %p\r\n", i, ptr[i]);
        vPortFree(ptr[i]);
    }

    printf("\r\n--- HEAP STATUS (after all freed) ---\r\n");
    HeapStats_t stats2;
    memset(&stats2, 0, sizeof(stats2));
    vPortGetHeapStats(&stats2);

    print_stat("Largest free block",    stats2.xSizeOfLargestFreeBlockInBytes);
    print_stat("Smallest free block",   stats2.xSizeOfSmallestFreeBlockInBytes);
    print_stat("Number of free blocks", stats2.xNumberOfFreeBlocks);

    printf("\r\n=== TEST COMPLETE FOR TEST 2===\r\n");

    vTaskDelete(NULL);
}

extern "C" void bfl_main(void)
{
    vInitializeBL602();

    xTaskCreate(
        merge_test_task,
        "merge",
        512,
        NULL,
        5,
        NULL
    );

    vTaskStartScheduler();
}
