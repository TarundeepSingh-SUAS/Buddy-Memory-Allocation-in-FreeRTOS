extern "C" {
#include <FreeRTOS.h>
#include <task.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
}

/* Number of test allocations */
#define ALLOC_COUNT 20

static void print_val(const char *label, size_t value)
{
    printf("%-22s : %u bytes\r\n", label, (unsigned)value);
}

static void fragmentation_task(void * /*param*/)
{
    printf("\r\n=== FRAGMENTATION TEST (ONE RUN ONLY) ===\r\n");

    void *ptrs[ALLOC_COUNT];
    memset(ptrs, 0, sizeof(ptrs));

    printf("\r\n--- STEP 1: Allocate blocks ---\r\n");

    /* Safe fixed-size allocation pattern */
    for (int i = 0; i < ALLOC_COUNT; i++)
    {
        size_t size = (512U << (i % 4));  // 512, 1024, 2048, 4096
        ptrs[i] = pvPortMalloc(size);

        printf("alloc[%02d] = %p  (%u bytes)\r\n",
               i, ptrs[i], (unsigned)size);
    }

    printf("\r\n--- STEP 2: Free half the blocks (creates fragmentation) ---\r\n");

    for (int i = 0; i < ALLOC_COUNT; i += 2)
    {
        if (ptrs[i])
        {
            printf("free[%02d] = %p\r\n", i, ptrs[i]);
            vPortFree(ptrs[i]);
        }
    }

    printf("\r\n--- STEP 3: Fragmentation Metrics ---\r\n");

    HeapStats_t stats;
    memset(&stats, 0, sizeof(stats));
    vPortGetHeapStats(&stats);

    print_val("Largest free block",   stats.xSizeOfLargestFreeBlockInBytes);
    print_val("Smallest free block",  stats.xSizeOfSmallestFreeBlockInBytes);
    print_val("Total free heap",      stats.xAvailableHeapSpaceInBytes);
    print_val("Number of free blocks",stats.xNumberOfFreeBlocks);

    printf("\r\n--- STEP 4: Clean up (free remaining blocks) ---\r\n");

    for (int i = 1; i < ALLOC_COUNT; i += 2)
    {
        if (ptrs[i])
        {
            printf("free[%02d] = %p\r\n", i, ptrs[i]);
            vPortFree(ptrs[i]);
        }
    }

    printf("\r\n=== TEST COMPLETE ===\n");

    /* Stop this task permanently */
    vTaskDelete(NULL);
}

extern "C" void bfl_main(void)
{
    vInitializeBL602();

    xTaskCreate(
        fragmentation_task,
        "frag_test",
        512,
        NULL,
        5,
        NULL
    );

    vTaskStartScheduler();
}
