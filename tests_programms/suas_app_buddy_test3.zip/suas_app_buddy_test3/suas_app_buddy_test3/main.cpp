extern "C" {
#include <FreeRTOS.h>
#include <task.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <bl_timer.h>      // BL602 hardware timer
}

/* Number of allocations per test */
#define TEST_COUNT 20

static void alloc_efficiency_task(void *)
{
    printf("\r\n=== ALLOCATION EFFICIENCY TEST ===\r\n");

    void *ptr[TEST_COUNT];

    printf("\r\n--- Measuring allocation time (microseconds) ---\r\n");

    for (int i = 0; i < TEST_COUNT; i++)
    {
        size_t size = (rand() % 3000) + 64;

        uint64_t t0 = bl_timer_now_us();
        ptr[i] = pvPortMalloc(size);
        uint64_t t1 = bl_timer_now_us();

        printf("alloc[%02d] size=%4u  time=%llu us  ptr=%p\r\n",
               i, (unsigned)size,
               (unsigned long long)(t1 - t0),
               ptr[i]);
    }

    printf("\r\n--- Measuring free time (microseconds) ---\r\n");

    for (int i = 0; i < TEST_COUNT; i++)
    {
        if (ptr[i])
        {
            uint64_t t0 = bl_timer_now_us();
            vPortFree(ptr[i]);
            uint64_t t1 = bl_timer_now_us();

            printf("free[%02d] time=%llu us\r\n",
                   i, (unsigned long long)(t1 - t0));
        }
    }

    printf("\r\n=== TEST COMPLETE ===\r\n");

    vTaskDelete(NULL);
}

extern "C" void bfl_main(void)
{
    vInitializeBL602();

    xTaskCreate(
        alloc_efficiency_task,
        "alloc_eff",
        512,
        NULL,
        5,
        NULL
    );

    vTaskStartScheduler();
}
